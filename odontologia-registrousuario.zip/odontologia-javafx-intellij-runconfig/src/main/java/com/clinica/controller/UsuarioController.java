package com.clinica.controller;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.stereotype.Component;
import com.clinica.service.UsuarioService;
@Component
public class UsuarioController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label mensajeLabel;
    private final UsuarioService service;
    public UsuarioController(UsuarioService s){this.service=s;}
    @FXML
    public void registrarUsuario(){
        String u=usernameField.getText();
        String p=passwordField.getText();
        if(u.isBlank()||p.isBlank()){
            mensajeLabel.setText("Complete todos los campos");
            return;
        }
        service.registrar(u,p);
        mensajeLabel.setText("Usuario registrado");
    }
}
