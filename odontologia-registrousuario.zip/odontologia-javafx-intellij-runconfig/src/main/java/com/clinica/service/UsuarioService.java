package com.clinica.service;
import com.clinica.models.Usuario;
import com.clinica.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
@Service
public class UsuarioService {
    private final UsuarioRepository repo;
    public UsuarioService(UsuarioRepository r){this.repo=r;}
    public Usuario registrar(String u,String p){
        return repo.save(new Usuario(u,p));
    }
}
